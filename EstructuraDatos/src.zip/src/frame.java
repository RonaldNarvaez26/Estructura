import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class frame extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame frame = new frame();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public frame() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("/Users/sabrigotalba/Desktop/FondoRestaurante.jpg"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 600);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout());
		
		/*JButton btnNewButton = new JButton("EVENTOS IMPORTANTES");
		btnNewButton.setBounds((width/2)+100, 260, 184, 29);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				IVentanaEventos newFrame= new IVentanaEventos();
				newFrame.setVisible(true);
				setVisible(false);
			}*/
		
		JButton btnNewButton_2 = new JButton("Notifiaciones y alertas");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VentanaNotificaciones newFrame=new VentanaNotificaciones();
				newFrame.setVisible(true);
				setVisible(false);
			}});
		btnNewButton_2.setBounds(640, 500, 210, 80);
		contentPane.add(btnNewButton_2);
		
		JButton btnNewButton_1 = new JButton("Gestion de clientes");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VentanaGestion newFrame=new VentanaGestion();
				newFrame.setVisible(true);
				setVisible(false);
			}});
		btnNewButton_1.setBounds(640, 300, 200, 80);
		contentPane.add(btnNewButton_1);
		
		JButton btnNewButton = new JButton("Menu");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				VentanaMenu newFrame=new VentanaMenu();
				newFrame.setVisible(true);
				setVisible(false);
			}});
		btnNewButton.setBounds(695, 100, 117, 80);
		contentPane.add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon("/Users/sabrigotalba/Desktop/FondoRestaurante.jpg"));
		lblNewLabel.setBounds(0, 0, 450, 272);
		contentPane.add(lblNewLabel,BorderLayout.CENTER);
		 String imagePath = "images/tu_imagen.png";

	        // Intenta cargar la imagen y establecerla como ícono en el JLabel
	        try {
	            //ImageIcon icon = new ImageIcon(getClass().getClassLoader().getResource(imagePath));
	            //label.setIcon(icon);
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
}